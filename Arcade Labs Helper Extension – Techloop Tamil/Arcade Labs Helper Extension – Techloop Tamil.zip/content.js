/*************************************************
 * 1. LAB SCORE CHECKER (Leaderboard Toggle)
 *************************************************/
const currentUrl = window.location.pathname;

if (!currentUrl.includes("/leaderboard")) {
  const assessmentTab = document.querySelector(
    ".lab-assessment__tab.js-open-lab-assessment-panel"
  );
  const leaderboard = document.querySelector("ql-leaderboard-container");
  const assessmentPanel = document.querySelector(
    ".lab-assessment__panel.js-lab-assessment-panel"
  );
  const mainWrapper = document.querySelector(
    "body.games-labs-show .l-main-wrapper"
  );

  let showingLeaderboard = false;

  function updateScoreUI() {
    if (!leaderboard || !assessmentPanel) return;

    leaderboard.style.display = showingLeaderboard ? "block" : "none";
    assessmentPanel.style.display = showingLeaderboard ? "none" : "block";
    if (assessmentTab)
      assessmentTab.style.display = showingLeaderboard ? "none" : "block";
    if (mainWrapper)
      mainWrapper.style.paddingRight = showingLeaderboard ? "64px" : "0px";
  }

  function createScoreToggle() {
    if (document.getElementById("arcade-score-toggle")) return;

    const btn = document.createElement("div");
    btn.id = "arcade-score-toggle";
    btn.innerHTML = "📊";

    Object.assign(btn.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      width: "56px",
      height: "56px",
      borderRadius: "50%",
      background: "#188038",
      color: "#fff",
      fontSize: "24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      zIndex: "9999",
      boxShadow: "0 4px 12px rgba(0,0,0,0.3)"
    });

    btn.onclick = () => {
      showingLeaderboard = !showingLeaderboard;
      updateScoreUI();
    };

    document.body.appendChild(btn);
    updateScoreUI();
  }

  if (leaderboard && assessmentPanel) {
    createScoreToggle();
  }
}

/*************************************************
 * 2. FETCH VIDEO MAP
 *************************************************/
const VIDEO_MAP_URL =
  "https://raw.githubusercontent.com/adhi2k/Extention_Videomap/main/videoMap.json";

let videoMap = {};

fetch(VIDEO_MAP_URL)
  .then(res => res.text())
  .then(text => {
    videoMap = JSON.parse(text.trim().replace(/^\uFEFF/, ""));
    initObserver();
  })
  .catch(() => initObserver());

/*************************************************
 * 3. DETECT LAB TITLE
 *************************************************/
function initObserver() {
  const selector = "h1.ql-display-large.lab-preamble__title";

  const observer = new MutationObserver(() => {
    const el = document.querySelector(selector);
    if (el && el.textContent) {
      observer.disconnect();
      handleChallengeTitle(el.textContent.trim());
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

/*************************************************
 * 4. HANDLE LAB (NO AUTO REDIRECT)
 *************************************************/
function handleChallengeTitle(title) {
  if (videoMap[title]) {
    showActionPopup(title, videoMap[title], true);
  } else {
    showActionPopup(title, null, false);
  }
}

/*************************************************
 * 5. IN-TAB SOLUTION POPUP
 *************************************************/
function showActionPopup(title, videoUrl, videoFound) {
  if (document.getElementById("arcade-action-popup")) return;

  const box = document.createElement("div");
  box.id = "arcade-action-popup";

  box.innerHTML = `
    <div style="
      position: fixed;
      bottom: 20px;
      left: 20px;
      max-width: 380px;
      background: #202124;
      color: #fff;
      padding: 16px;
      border-radius: 14px;
      font-family: Arial, sans-serif;
      box-shadow: 0 8px 22px rgba(0,0,0,0.45);
      z-index: 9999;
    ">
      <div style="font-weight:bold;margin-bottom:6px;">
        ${videoFound ? "✅ Video Available" : "🚧 Video Coming Soon"}
      </div>

      <div style="font-size:13px;line-height:1.5;margin-bottom:14px;">
        ${
          videoFound
            ? `Solution video found for:<br><span style="color:#8ab4f8;">"${title}"</span>`
            : `Soon I will upload a video for this lab:<br><span style="color:#8ab4f8;">"${title}"</span>`
        }
      </div>

      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        ${
          videoFound
            ? `<a href="${videoUrl}" target="_blank"
                 style="background:#1a73e8;color:#fff;padding:8px 12px;
                        border-radius:6px;text-decoration:none;font-size:13px;font-weight:bold;">
                 ▶ Watch Video
               </a>`
            : ""
        }

        <a href="https://www.youtube.com/@Techloop_Tamil" target="_blank"
           style="background:#ff0000;color:#fff;padding:8px 12px;
                  border-radius:6px;text-decoration:none;font-size:13px;font-weight:bold;">
          🔔 Subscribe
        </a>

        <a href="https://adhi2k.github.io/Extention_Videomap/upi.html" target="_blank"
           style="background:#ffdd00;color:#000;padding:8px 12px;
                  border-radius:6px;text-decoration:none;font-size:13px;font-weight:bold;">
          ☕ Buy Me a Coffee
        </a>
      </div>

      <div id="arcade-close"
        style="position:absolute;top:8px;right:10px;
               cursor:pointer;font-size:16px;color:#9aa0a6;">
        ✖
      </div>
    </div>
  `;

  document.body.appendChild(box);
  document.getElementById("arcade-close").onclick = () => box.remove();
}
