/*************************************************
 * LAB SCORE CHECKER (Leaderboard Toggle)
 *************************************************/

const currentUrl = window.location.pathname;

if (!currentUrl.includes("/leaderboard")) {

  const assessmentTab =
    document.querySelector(".lab-assessment__tab.js-open-lab-assessment-panel");

  const leaderboard =
    document.querySelector("ql-leaderboard-container");

  const assessmentPanel =
    document.querySelector(".lab-assessment__panel.js-lab-assessment-panel");

  const mainWrapper =
    document.querySelector("body.games-labs-show .l-main-wrapper");

  let showingLeaderboard = false;

  function updateScoreUI() {

    if (!leaderboard || !assessmentPanel) return;

    leaderboard.style.display =
      showingLeaderboard ? "block" : "none";

    assessmentPanel.style.display =
      showingLeaderboard ? "none" : "block";

    if (assessmentTab)
      assessmentTab.style.display =
        showingLeaderboard ? "none" : "block";

    if (mainWrapper)
      mainWrapper.style.paddingRight =
        showingLeaderboard ? "64px" : "0px";
  }

  function createScoreToggle() {

    if (document.getElementById("arcade-score-toggle"))
      return;

    const btn = document.createElement("div");

    btn.innerHTML = "📊";

    Object.assign(btn.style, {

      position: "fixed",
      bottom: "20px",
      right: "20px",
      width: "56px",
      height: "56px",
      borderRadius: "50%",
      background: "#188038",
      color: "#fff",
      fontSize: "24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer",
      zIndex: "9999",
      boxShadow: "0 4px 12px rgba(0,0,0,0.3)"

    });

    btn.onclick = () => {

      showingLeaderboard =
        !showingLeaderboard;

      updateScoreUI();
    };

    document.body.appendChild(btn);

    updateScoreUI();
  }

  if (leaderboard && assessmentPanel)
    createScoreToggle();
}


/*************************************************
 * FETCH videoMap.json
 *************************************************/

const VIDEO_MAP_URL =
  "https://raw.githubusercontent.com/adhi2k/Extention_Videomap/main/videoMap.json";

let videoMap = {};

fetch(VIDEO_MAP_URL)
  .then(res => res.text())
  .then(text => {

    videoMap =
      JSON.parse(text.trim().replace(/^\uFEFF/, ""));

    initObserver();
  })
  .catch(() => initObserver());


/*************************************************
 * DETECT LAB TITLE
 *************************************************/

function initObserver() {

  const selector =
    "h1.ql-display-large.lab-preamble__title";

  const observer =
    new MutationObserver(() => {

      const el =
        document.querySelector(selector);

      if (el && el.textContent) {

        observer.disconnect();

        handleChallengeTitle(
          el.textContent.trim()
        );
      }
    });

  observer.observe(document.body, {

    childList: true,
    subtree: true
  });
}


/*************************************************
 * HANDLE LAB TITLE
 *************************************************/

function handleChallengeTitle(title) {

  const lab =
    videoMap[title];

  if (!lab) {

    showPopup(title, null, null);

    return;
  }

  const videoUrl =
    typeof lab === "string"
      ? lab
      : lab.video || null;

  const githubUrl =
    typeof lab === "object"
      ? lab.github || null
      : null;

  showPopup(title, videoUrl, githubUrl);
}


/*************************************************
 * SHOW POPUP
 *************************************************/

function showPopup(title, videoUrl, githubUrl) {

  if (document.getElementById("arcade-popup"))
    return;

  const box =
    document.createElement("div");

  box.innerHTML = `

<div style="
 position:fixed;
 bottom:20px;
 left:20px;
 max-width:400px;
 background:#202124;
 color:#fff;
 padding:16px;
 border-radius:14px;
 z-index:9999;
 box-shadow:0 8px 22px rgba(0,0,0,0.45);
">

<div style="font-weight:bold;margin-bottom:8px;">

${(videoUrl || githubUrl)
 ? "✅ Resources Available"
 : "🚧 Resources Coming Soon"}

</div>

<div style="margin-bottom:12px;">
${title}
</div>

<div style="display:flex;gap:8px;flex-wrap:wrap;">

${videoUrl ? `
<button id="videoBtn"
style="background:#1a73e8;color:white;border:none;padding:8px 12px;border-radius:6px;cursor:pointer;">
▶ Watch Video
</button>` : ""}

${githubUrl ? `
<button id="githubBtn"
style="background:#24292e;color:white;border:none;padding:8px 12px;border-radius:6px;cursor:pointer;">
💻 GitHub Code
</button>` : ""}

<a href="https://www.youtube.com/@Techloop_Tamil"
target="_blank"
style="background:#ff0000;color:white;padding:8px 12px;border-radius:6px;text-decoration:none;">
Subscribe
</a>

<a href="https://adhi2k.github.io/Extention_Videomap/upi.html"
target="_blank"
style="background:#ffdd00;color:black;padding:8px 12px;border-radius:6px;text-decoration:none;">
Buy Me Coffee
</a>

</div>

<div id="closePopup"
style="position:absolute;top:6px;right:10px;cursor:pointer;">
✖
</div>

</div>
`;

  document.body.appendChild(box);

  document.getElementById("closePopup")
    .onclick = () => box.remove();

  if (videoUrl)
    document.getElementById("videoBtn")
      .onclick = () =>
        chrome.runtime.sendMessage({
          video: videoUrl
        });

  if (githubUrl)
    document.getElementById("githubBtn")
      .onclick = () =>
        chrome.runtime.sendMessage({
          github: githubUrl
        });
}
