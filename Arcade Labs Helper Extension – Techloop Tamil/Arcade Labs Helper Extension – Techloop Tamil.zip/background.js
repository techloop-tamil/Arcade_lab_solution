chrome.runtime.onMessage.addListener((message) => {
  if (message.video && typeof message.video === "string") {
    chrome.tabs.create({ url: message.video });
  }
});
