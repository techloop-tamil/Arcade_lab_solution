chrome.runtime.onMessage.addListener((message) => {
  if (message.type === "NO_VIDEO_FOUND") {
    const msgDiv = document.getElementById("message");
    msgDiv.textContent = `Soon I will upload a video for this lab: "${message.labTitle}"`;
  }
});
