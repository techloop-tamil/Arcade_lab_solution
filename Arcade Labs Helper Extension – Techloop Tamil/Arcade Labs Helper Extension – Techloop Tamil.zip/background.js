chrome.runtime.onMessage.addListener((message) => {

  if (message.video) {
    chrome.tabs.create({ url: message.video });
  }

  if (message.github) {
    chrome.tabs.create({ url: message.github });
  }

});
